﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using Spectrum.Models;

namespace Spectrum
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = false)]
    public class AddActivity : AppCompatActivity
    {
        Button btnAding;
        EditText txtUser;
        EditText txtPass;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Add);

            btnAding = FindViewById<Button>(Resource.Id.btnAddUser);
            btnAding.Click += BtnAding_Click;

            txtUser = FindViewById<EditText>(Resource.Id.txtUserName);
            txtPass = FindViewById<EditText>(Resource.Id.txtPassword);
        }

        private void BtnAding_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txtUser.Text))
            {
                Toast.MakeText(ApplicationContext, "Enter a Name", ToastLength.Long).Show();
                return;
            }

            if (txtUser.Length() < 5)
            {
                Toast.MakeText(ApplicationContext, "Must be more than 5 characters", ToastLength.Long).Show();
                return;
            }
            if (txtUser.Length() > 12)
            {
                Toast.MakeText(ApplicationContext, "Must be at least than 12 characters", ToastLength.Long).Show();
                return;
            }

            if (string.IsNullOrEmpty(txtPass.Text))
            {
                Toast.MakeText(ApplicationContext, "Enter a Password", ToastLength.Long).Show();
                return;
            }

            MainActivity.ListUsers.Add(new Users(txtUser.Text, txtPass.Text));
            Toast.MakeText(ApplicationContext, "The record has been added successfully.", ToastLength.Long).Show();
        }
    }
}