﻿namespace Spectrum.Models
{
    public class Users
    {
        #region Constructor
       
        public Users(string name, string password)
        {
            Name = name;
            Password = password;
        }

        #endregion

        #region Properties

        public string Name { get; set; }
        public string Password { get; set; }

        #endregion
        

        public override string ToString()
        {
            return Name;
        }
    }
}