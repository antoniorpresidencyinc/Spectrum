﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Support.V7.App;
using Android.Widget;
using Spectrum.Models;
using System.Collections.Generic;

namespace Spectrum
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = false)]
    public class ListActivity : AppCompatActivity
    {
        ListView lst;
        public static List<Users> ListUsers = new List<Users>();

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.List);

            lst = FindViewById<ListView>(Resource.Id.listView1);
            lst.Adapter = new ArrayAdapter<Users>(this, Android.Resource.Layout.SimpleListItem1, Android.Resource.Id.Text1, MainActivity.ListUsers);

            lst.ItemClick += Lst_ItemClick;
        }

        private void Lst_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            var intent = new Intent(this, typeof(DetailsActivity));

            intent.PutExtra("UserSelected", e.Position); // e.Position is the position in the list of the item the use touched

            StartActivity(intent);
        }
    }
}