﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Support.V7.App;
using Android.Widget;

namespace Spectrum
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = false)]
    public class DetailsActivity: AppCompatActivity
    {
        TextView txtN;
        TextView txtP;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Details);

            //
            // Retrieve the position of the item we need to display.
            //
            int position = Intent.GetIntExtra("UserSelected", -1);

            //
            // Use the position to lookup the grocery item.
            //
            var item = MainActivity.ListUsers[position];

            txtN = FindViewById<TextView>(Resource.Id.textView1);
            txtN.Text = "User Name: " + item.Name;
            txtP = FindViewById<TextView>(Resource.Id.textView2);
            txtP.Text = "Password: " + item.Password;

        }

    }
}