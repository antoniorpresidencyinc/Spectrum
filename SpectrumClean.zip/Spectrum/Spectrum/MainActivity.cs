﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Support.V7.App;
using Android.Widget;
using Spectrum.Models;
using System.Collections.Generic;

namespace Spectrum
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        Button btnNew;
        Button btnList;

      
        public static List<Users> ListUsers = new List<Users>();
        protected override void OnCreate(Bundle savedInstanceState)
        {

            // Pre-load with some sample data for convenience.
            ListUsers.Add(new Users("Antonio Rivera", "mod3st@"));
            ListUsers.Add(new Users("Carlos Nieblas", "Frog@"));
            ListUsers.Add(new Users("Veronica Quizan", "Veroch@"));

            base.OnCreate(savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            btnNew = FindViewById<Button>(Resource.Id.btnNewUser);
            btnNew.Click += BtnNew_Click;

            btnList = FindViewById<Button>(Resource.Id.btnListUser);
            btnList.Click += BtnList_Click;

        }

        private void BtnList_Click(object sender, System.EventArgs e)
        {
            Intent intent = new Intent(this, typeof(ListActivity));
            StartActivity(intent);
        }

        private void BtnNew_Click(object sender, System.EventArgs e)
        {
           // SetContentView(Resource.Layout.Register);
            //Intent intent = new Intent(this, typeof(RegisterActivity));
            Intent intent = new Intent(this, typeof(AddActivity));
            StartActivity(intent);

        }

        protected override void OnStart()
        {
            base.OnStart();
        }

        protected override void OnResume()
        {
            base.OnResume();
        }

        protected override void OnPause()
        {
            base.OnPause();
        }

        protected override void OnStop()
        {
            base.OnStop();
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
        }

        protected override void OnRestart()
        {
            base.OnRestart();
        }



    }
}